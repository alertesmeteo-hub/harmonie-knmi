/* Vigilance jours suivants v2.1 — rendu des trois granularités du bulletin Météo-France.
   J+2 / J+3 : départements · J+4 / J+5 : quarts de la France · J+6 / J+7 : national. */
(function () {
'use strict';

var LEVEL_TEXT = {
  none: 'Quasi nulle',
  low: 'Faible (≤ 30 %)',
  medium: 'Moyenne (> 30 ≤ 70 %)',
  high: 'Élevée (> 70 %)'
};

var PHEN_NAMES = {
  vent: 'Vent', pluie_inondation: 'Pluie-inondation', orages: 'Orages',
  neige_verglas: 'Neige-verglas', canicule: 'Canicule', grand_froid: 'Grand froid',
  vagues_submersion: 'Vagues-submersion'
};

var PHEN_SYMBOL = {
  vent: '⚑', pluie_inondation: '≋', orages: 'ϟ', neige_verglas: '✣',
  canicule: '☼', grand_froid: '✻', vagues_submersion: '≈'
};

var QUADRANT_NAMES = {
  NO: 'Quart nord-ouest', NE: 'Quart nord-est',
  SO: 'Quart sud-ouest', SE: 'Quart sud-est'
};

/* Répartition indicative des départements entre les quarts de la France.
   Météo-France ne publie pas de découpage officiel : ces zones sont une
   représentation approchée de « grandes zones correspondant aux quarts ». */
var QUADRANT_OF = (function () {
  var groups = {
    NE: '02,03,08,10,18,21,25,39,45,51,52,54,55,57,58,59,60,62,67,68,70,71,75,77,80,88,89,90,91,92,93,94',
    NO: '14,22,27,28,29,35,36,37,41,44,49,50,53,56,61,72,76,78,79,85,86,95',
    SE: '01,04,05,06,07,12,13,15,26,2A,2B,30,34,38,42,43,48,63,69,73,74,83,84',
    SO: '09,11,16,17,19,23,24,31,32,33,40,46,47,64,65,66,81,82,87'
  };
  var out = {};
  Object.keys(groups).forEach(function (zone) {
    groups[zone].split(',').forEach(function (code) { out[code] = zone; });
  });
  return out;
})();

function esc(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c];
  });
}

function normalizeCode(code) {
  code = String(code || '').toUpperCase();
  if (code === '69M') return '69';
  if (code === '75C') return '75';
  return code;
}

function levelColour(map, level) {
  var styles = getComputedStyle(map);
  var value = styles.getPropertyValue('--vjs-' + (level || 'none'));
  return (value || '').trim() || '#f7f8f9';
}

function phenomenonLabel(slug) {
  return PHEN_NAMES[slug] || String(slug || '').replace(/_/g, '-');
}

/* ------------------------------------------------------------------ carte */

function injectMap(map) {
  var template = document.getElementById('vjs-map-template');
  if (!template || map.querySelector('svg')) return map.querySelector('svg');
  var svg = template.content
    ? template.content.querySelector('svg')
    : template.querySelector('svg');
  if (!svg) return null;
  var clone = svg.cloneNode(true);
  map.insertBefore(clone, map.firstChild);
  return clone;
}

function readCard(map) {
  var holder = map.querySelector('.vjs-card-data');
  if (!holder) return null;
  try { return JSON.parse(holder.textContent); } catch (e) { return null; }
}

/* --------------------------------------------------------------- infobulle */

function tooltipHtml(map, title, level, phenomena) {
  var html = '<strong>' + esc(title) + '</strong>';
  if (!phenomena || !phenomena.length) {
    html += '<div class="vjs-tooltip-line"><span class="vjs-tooltip-dot" style="background:' +
      levelColour(map, 'none') + '"></span><span>Probabilité quasi nulle</span></div>';
    return html;
  }
  phenomena.forEach(function (item) {
    var slug = item.phenomenon || item;
    var itemLevel = item.level || level || 'none';
    html += '<div class="vjs-tooltip-line"><span class="vjs-tooltip-dot" style="background:' +
      levelColour(map, itemLevel) + '"></span><span>' + esc(phenomenonLabel(slug)) + ' · ' +
      esc(LEVEL_TEXT[itemLevel] || itemLevel) + '</span></div>';
  });
  return html;
}

function positionTooltip(map, tip, event) {
  var rect = map.getBoundingClientRect();
  var x = (event && event.clientX ? event.clientX - rect.left : rect.width / 2) + 10;
  var y = (event && event.clientY ? event.clientY - rect.top : rect.height / 2) + 10;
  var w = tip.offsetWidth || 220;
  var h = tip.offsetHeight || 90;
  if (x + w > rect.width - 8) x = Math.max(8, x - w - 22);
  if (y + h > rect.height - 8) y = Math.max(8, y - h - 22);
  tip.style.left = x + 'px';
  tip.style.top = y + 'px';
}

function showTooltip(map, tip, html, event, groupSelector) {
  tip.innerHTML = html;
  tip.classList.add('is-visible');
  tip.setAttribute('aria-hidden', 'false');
  positionTooltip(map, tip, event);
  map.querySelectorAll('.vjs-dept.is-hover').forEach(function (p) { p.classList.remove('is-hover'); });
  if (groupSelector) {
    map.querySelectorAll(groupSelector).forEach(function (p) { p.classList.add('is-hover'); });
  }
}

function hideTooltip(map, tip) {
  tip.classList.remove('is-visible');
  tip.setAttribute('aria-hidden', 'true');
  map.querySelectorAll('.vjs-dept.is-hover').forEach(function (p) { p.classList.remove('is-hover'); });
}

/* ---------------------------------------------------------------- symboles */

function drawMarkers(svg, markers, map) {
  var previous = svg.querySelector('.vjs-generated-markers');
  if (previous) previous.remove();
  if (!markers || !markers.length) return;

  var ns = 'http://www.w3.org/2000/svg';
  var group = document.createElementNS(ns, 'g');
  group.setAttribute('class', 'vjs-generated-markers');

  markers.forEach(function (marker) {
    if (!isFinite(marker.x) || !isFinite(marker.y)) return;
    var size = marker.size || 5.2;
    var cell = document.createElementNS(ns, 'g');
    cell.setAttribute('class', 'vjs-marker');
    cell.setAttribute('transform', 'translate(' + (marker.x - size / 2) + ' ' + (marker.y - size / 2) + ')');

    var box = document.createElementNS(ns, 'rect');
    box.setAttribute('width', size);
    box.setAttribute('height', size);
    box.setAttribute('fill', levelColour(map, marker.level));

    var glyph = document.createElementNS(ns, 'text');
    glyph.setAttribute('x', size / 2);
    glyph.setAttribute('y', size / 2 + 0.05);
    glyph.setAttribute('fill', (marker.level === 'medium' || marker.level === 'high') ? '#fff' : '#111');
    glyph.setAttribute('font-size', size * 0.6);
    glyph.textContent = PHEN_SYMBOL[marker.phenomenon] || '•';

    cell.appendChild(box);
    cell.appendChild(glyph);
    group.appendChild(cell);
  });
  svg.appendChild(group);
}

function centroidsByZone(svg) {
  var sums = {};
  svg.querySelectorAll('.vjs-dept').forEach(function (path) {
    var code = normalizeCode(path.dataset.code);
    var zone = QUADRANT_OF[code];
    if (!zone) return;
    if (!sums[zone]) sums[zone] = { x: 0, y: 0, n: 0 };
    sums[zone].x += parseFloat(path.dataset.cx) || 0;
    sums[zone].y += parseFloat(path.dataset.cy) || 0;
    sums[zone].n += 1;
  });
  var out = {};
  Object.keys(sums).forEach(function (zone) {
    out[zone] = { x: sums[zone].x / sums[zone].n, y: sums[zone].y / sums[zone].n };
  });
  return out;
}

function centroidAll(svg) {
  var x = 0, y = 0, n = 0;
  svg.querySelectorAll('.vjs-dept').forEach(function (path) {
    x += parseFloat(path.dataset.cx) || 0;
    y += parseFloat(path.dataset.cy) || 0;
    n += 1;
  });
  return n ? { x: x / n, y: y / n } : { x: 0, y: 0 };
}

/* ------------------------------------------------------------- granularités */

function initDepartments(map, svg, tip, card) {
  var departments = card.departments || {};
  svg.querySelectorAll('.vjs-dept').forEach(function (path) {
    var code = normalizeCode(path.dataset.code);
    var info = departments[code] || { name: path.dataset.name, level: 'none', phenomena: [] };
    var level = info.level || 'none';
    path.style.fill = levelColour(map, level);

    var title = (info.name || path.dataset.name || code) + ' (' + code + ')';
    var html = tooltipHtml(map, title, level, info.phenomena);
    var selector = '.vjs-dept[data-code="' + (window.CSS && CSS.escape ? CSS.escape(code) : code) + '"]';

    bind(map, tip, path, html, selector);
    path.setAttribute('aria-label', title + ' — ' + (LEVEL_TEXT[level] || level));
  });

  drawMarkers(svg, (card.markers || []).map(function (marker) {
    return { phenomenon: marker.phenomenon, level: marker.level, x: marker.svg_x, y: marker.svg_y };
  }), map);
}

function initQuadrants(map, svg, tip, card) {
  var zones = card.zones || {};
  svg.querySelectorAll('.vjs-dept').forEach(function (path) {
    var code = normalizeCode(path.dataset.code);
    var zoneKey = QUADRANT_OF[code];
    var zone = (zoneKey && zones[zoneKey]) || { level: 'none', phenomena: [] };
    var colour = levelColour(map, zone.level || 'none');
    path.style.fill = colour;
    path.style.stroke = colour;      /* les départements se fondent : on lit 4 zones */

    var title = QUADRANT_NAMES[zoneKey] || 'France';
    var html = tooltipHtml(map, title, zone.level, zone.phenomena);
    bind(map, tip, path, html, '.vjs-dept[data-zone="' + zoneKey + '"]');
    path.setAttribute('data-zone', zoneKey || '');
    path.setAttribute('aria-label', title + ' — ' + (LEVEL_TEXT[zone.level] || zone.level));
  });

  var centres = centroidsByZone(svg);
  var markers = [];
  Object.keys(zones).forEach(function (zoneKey) {
    var zone = zones[zoneKey];
    var centre = centres[zoneKey];
    if (!centre || !zone.phenomena || !zone.phenomena.length) return;
    zone.phenomena.forEach(function (item, index) {
      markers.push({
        phenomenon: item.phenomenon,
        level: item.level || zone.level,
        x: centre.x + (index - (zone.phenomena.length - 1) / 2) * 5.2,
        y: centre.y,
        size: 5.6
      });
    });
  });
  drawMarkers(svg, markers, map);
}

function initNational(map, svg, tip, card) {
  var national = card.national || { level: 'none', phenomena: [] };
  var colour = levelColour(map, national.level || 'none');
  svg.querySelectorAll('.vjs-dept').forEach(function (path) {
    path.style.fill = colour;
    path.style.stroke = colour;
    var html = tooltipHtml(map, 'France métropolitaine', national.level, national.phenomena);
    bind(map, tip, path, html, '.vjs-dept');
    path.setAttribute('aria-label', 'France métropolitaine — ' + (LEVEL_TEXT[national.level] || national.level));
  });

  var centre = centroidAll(svg);
  var markers = (national.phenomena || []).map(function (item, index, list) {
    return {
      phenomenon: item.phenomenon,
      level: item.level || national.level,
      x: centre.x + (index - (list.length - 1) / 2) * 6,
      y: centre.y,
      size: 6.4
    };
  });
  drawMarkers(svg, markers, map);
}

function bind(map, tip, path, html, selector) {
  path.addEventListener('mouseenter', function (e) { showTooltip(map, tip, html, e, selector); });
  path.addEventListener('mousemove', function (e) { positionTooltip(map, tip, e); });
  path.addEventListener('mouseleave', function () { hideTooltip(map, tip); });
  path.addEventListener('focus', function (e) { showTooltip(map, tip, html, e, selector); });
  path.setAttribute('tabindex', '0');
  path.setAttribute('role', 'button');
}

/* ------------------------------------------------------------------- init */

function initMap(map) {
  if (map.dataset.vjsReady === '1') return;
  var card = readCard(map);
  if (!card) return;
  var svg = injectMap(map);
  if (!svg) return;
  map.dataset.vjsReady = '1';

  var tip = map.querySelector('.vjs-tooltip');
  var granularity = map.dataset.granularity || card.granularity || 'department';

  if (granularity === 'quadrant') initQuadrants(map, svg, tip, card);
  else if (granularity === 'national') initNational(map, svg, tip, card);
  else initDepartments(map, svg, tip, card);

  map.addEventListener('mouseleave', function () { hideTooltip(map, tip); });
  map.addEventListener('keydown', function (e) { if (e.key === 'Escape') hideTooltip(map, tip); });
}

function initAll() {
  document.querySelectorAll('.vjs-map').forEach(initMap);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initAll);
else initAll();
})();
