<?php
/**
 * Plugin Name: Vigilance Jours Suivants
 * Description: Cartes J+2 à J+7 du bulletin Météo-France « Prévision des phénomènes dangereux », au niveau de détail réellement publié par la source (départements J+2/J+3, quarts de la France J+4/J+5, national J+6/J+7).
 * Version: 2.1.4
 * Author: Alertes-Météo.com
 * Requires at least: 5.8
 * Requires PHP: 7.0
 * Text Domain: vigilance-jours-suivants
 */

if (!defined('ABSPATH')) exit;

/*
 * Garde-fou anti-collision.
 *
 * La v2.0 du module déclarait déjà vjs_render(), vjs_fetch_data(),
 * vjs_validate_data(), etc. Si les deux extensions sont actives en même temps,
 * PHP lève « Cannot redeclare function » et WordPress refuse l'activation avec
 * une erreur fatale.
 *
 * Attention : PHP lie les fonctions d'un fichier à la COMPILATION, pas à
 * l'exécution. Un simple return en tête de fichier ne suffit donc pas — les
 * fonctions seraient déjà déclarées. C'est pour cela que tout le corps du
 * module vit dans includes/vjs-core.php, chargé par un require_once qui, lui,
 * ne s'exécute que si la voie est libre.
 */
if (defined('VJS_VERSION') || function_exists('vjs_render') || function_exists('vjs_fetch_data')) {

    // On identifie le fichier fautif pour éviter à l'administrateur de le chercher.
    $vjs_conflict_file = '';
    $vjs_conflict_version = defined('VJS_VERSION') ? VJS_VERSION : '';
    foreach (array('vjs_render', 'vjs_fetch_data', 'vjs_validate_data', 'vjs_settings_page') as $vjs_probe) {
        if (function_exists($vjs_probe)) {
            try {
                $vjs_reflection = new ReflectionFunction($vjs_probe);
                $vjs_conflict_file = (string) $vjs_reflection->getFileName();
            } catch (Throwable $vjs_error) {
                $vjs_conflict_file = '';
            }
            break;
        }
    }
    $vjs_self_file = __FILE__;

    add_action('admin_notices', function () use ($vjs_conflict_file, $vjs_conflict_version, $vjs_self_file) {
        if (!current_user_can('activate_plugins')) return;

        $shorten = function ($path) {
            if ($path === '') return '';
            $base = defined('WP_PLUGIN_DIR') ? WP_PLUGIN_DIR : '';
            if ($base !== '' && strpos($path, $base) === 0) {
                return ltrim(substr($path, strlen($base)), '/\\');
            }
            return $path;
        };

        echo '<div class="notice notice-error"><p><strong>Vigilance jours suivants</strong> — '
           . 'une autre version du module est déjà chargée, ce module reste donc en veille '
           . 'pour ne pas provoquer d\'erreur fatale.</p>';

        if ($vjs_conflict_file !== '') {
            echo '<p>Version déjà en mémoire'
               . ($vjs_conflict_version !== '' ? ' : <strong>' . esc_html($vjs_conflict_version) . '</strong>' : '')
               . '<br>Fichier : <code>' . esc_html($shorten($vjs_conflict_file)) . '</code>'
               . '<br>Ce module-ci : <code>' . esc_html($shorten($vjs_self_file)) . '</code></p>';
            echo '<p>Dans <em>Extensions</em>, désactivez puis <strong>supprimez</strong> celle qui correspond '
               . 'au premier chemin. Si les deux chemins sont identiques, c\'est que le dossier de l\'extension '
               . 'existe en double dans <code>wp-content/plugins/</code> : supprimez le doublon.</p>';
        } else {
            echo '<p>Ouvrez <em>Extensions</em>, désactivez puis <strong>supprimez</strong> l\'ancienne version '
               . '(v2.0), puis rechargez cette page.</p>';
        }
        echo '</div>';
    });
    return;
}

define('VJS_VERSION', '2.1.4');
define('VJS_PLUGIN_FILE', __FILE__);
define('VJS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('VJS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('VJS_DEFAULT_DATA_URL', 'https://raw.githubusercontent.com/alertesmeteo-hub/harmonie-knmi/main/data/vigilance-jours-suivants.json');

require_once VJS_PLUGIN_DIR . 'includes/vjs-core.php';
