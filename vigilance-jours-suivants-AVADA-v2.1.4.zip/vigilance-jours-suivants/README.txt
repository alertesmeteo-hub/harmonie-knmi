VIGILANCE JOURS SUIVANTS v2.1.4
================================

Shortcode :
  [vigilance_jours_suivants]

Sans le titre :
  [vigilance_jours_suivants title="0"]

Autres attributs :
  cache="30"          durée du cache en minutes (5 à 360)
  data_url="https://…" surcharge ponctuelle de la source

AIDE
----
AIDE.txt (à la racine de cette extension) liste tous les shortcodes, leurs
attributs, la marche à suivre dans Avada et le dépannage.

La même aide est dans l'administration, avec un bouton « Copier » par code :
  Réglages > Vigilance jours suivants

On y trouve la liste des shortcodes avec un bouton « Copier » pour chacun, le
tableau des attributs, la marche à suivre pour poser le module dans Fusion
Builder (Avada), l'état de la source, et un tableau de dépannage.

Source des données : Réglages > Vigilance jours suivants
URL par défaut :
  https://raw.githubusercontent.com/alertesmeteo-hub/harmonie-knmi/main/data/vigilance-jours-suivants.json


AVANT D'ACTIVER
---------------
Si la v2.0 est encore installée, DÉSACTIVEZ-LA ET SUPPRIMEZ-LA d'abord.
Les deux versions déclarent les mêmes fonctions : activer les deux en même
temps provoquait une erreur fatale. Depuis la 2.1.2 le module se met en veille
au lieu de planter, et affiche un message dans l'administration — mais il ne
fonctionnera qu'une fois l'ancienne extension supprimée.


CE QUI CHANGE PAR RAPPORT À LA v2.0
-----------------------------------

1. Schéma de données v3 : trois granularités, conformes au bulletin Météo-France.

   J+2 / J+3   -> détail par département (96 départements)
   J+4 / J+5   -> par quart de la France
   J+6 / J+7   -> France métropolitaine, sans découpage géographique

   La v2.0 affichait 96 départements sur les cinq cartes. Météo-France ne publie
   pas cette précision au-delà de J+3 : les valeurs départementales de J+4 à J+7
   étaient donc inventées. Elles ont disparu.

2. Noms de départements corrigés. Le fond de carte provenait d'un jeu Highcharts
   dont cinq entrées étaient en anglais et remontaient dans les infobulles :
     06 Maritime Alps       -> Alpes-Maritimes
     65 Hautes Pyrenees     -> Hautes-Pyrénées
     73 Savoy               -> Savoie
     74 Upper Savoy         -> Haute-Savoie
     90 Territoire-de-Belfort -> Territoire de Belfort

3. Poids de page divisé par ~6. Le fond SVG était inséré 5 fois (environ 1,5 Mo
   de HTML). Il n'est plus écrit qu'une fois, dans un <template> que le script
   clone dans chaque carte. Les tracés ont aussi été nettoyés.
   HTML rendu : ~250 Ko au lieu de ~1,6 Mo.

4. Palette alignée sur celle du bulletin. Les couleurs ne sont plus codées en
   dur : elles sont lues dans la légende du PDF et transmises dans le JSON, puis
   appliquées via les variables CSS --vjs-none / low / medium / high. Si
   Météo-France change une teinte, le module suit sans mise à jour.

5. Plus aucune source de repli tierce. La v2.0 pouvait aller lire un autre site
   météo quand Météo-France échouait ; ce comportement a été supprimé.


PROBABILITÉS
------------
  quasi nulle
  faible    ≤ 30 %
  moyenne   > 30 % ≤ 70 %
  élevée    > 70 %


REPLI
-----
data/fallback.json contient le dernier bulletin connu au moment de l'empaquetage.
Il ne sert que si l'URL GitHub est injoignable, et le module l'indique alors
explicitement à l'écran.


LICENCE DES DONNÉES
-------------------
Bulletin « Prévision des phénomènes dangereux » © Météo-France,
Licence Ouverte / Open Licence (Etalab 2.0). L'attribution est affichée sous
chaque rendu du module.
