<?php
/**
 * Corps du module Vigilance Jours Suivants.
 * Chargé par vigilance-jours-suivants.php uniquement si aucune autre version
 * n'est déjà en mémoire — voir le garde-fou du fichier principal.
 */

if (!defined('ABSPATH') || !defined('VJS_VERSION')) exit;

const VJS_LABELS = ['J+2', 'J+3', 'J+4', 'J+5', 'J+6 et J+7'];
const VJS_LEVELS = ['none', 'low', 'medium', 'high'];

/* ------------------------------------------------------------------ assets */

add_action('wp_enqueue_scripts', function () {
    wp_register_style('vjs-style', VJS_PLUGIN_URL . 'assets/vjs.css', [], VJS_VERSION);
    wp_register_script('vjs-script', VJS_PLUGIN_URL . 'assets/vjs.js', [], VJS_VERSION, true);
});

/* ---------------------------------------------------------------- réglages */

add_action('admin_menu', function () {
    add_options_page('Vigilance jours suivants', 'Vigilance jours suivants',
        'manage_options', 'vigilance-jours-suivants', 'vjs_settings_page');
});

add_action('admin_init', function () {
    register_setting('vjs_settings', 'vjs_data_url', [
        'type' => 'string',
        'sanitize_callback' => 'esc_url_raw',
        'default' => VJS_DEFAULT_DATA_URL,
    ]);

    add_settings_section('vjs_main', 'Source des données', function () {
        echo '<p>URL RAW du fichier <code>data/vigilance-jours-suivants.json</code> publié par le dépôt GitHub.</p>';
    }, 'vigilance-jours-suivants');

    add_settings_field('vjs_data_url', 'URL JSON', function () {
        $value = get_option('vjs_data_url', VJS_DEFAULT_DATA_URL);
        echo '<input type="url" class="regular-text code" style="width:100%;max-width:780px" name="vjs_data_url" value="' . esc_attr($value) . '">';
    }, 'vigilance-jours-suivants', 'vjs_main');
});

/** Liste de référence des shortcodes, affichée dans l'admin. */
function vjs_shortcode_reference() {
    return [
        [
            'code' => '[vigilance_jours_suivants]',
            'title' => 'Affichage complet',
            'desc' => "Titre, synthèses, les 5 cartes, la légende et la mention de source. C'est celui à utiliser dans 99 % des cas.",
        ],
        [
            'code' => '[vigilance_jours_suivants title="0"]',
            'title' => 'Sans le bloc de titre',
            'desc' => "Masque le titre « Vigilance jours suivants », le sous-titre et la date du bulletin. À utiliser quand le titre est déjà posé par Avada juste au-dessus, pour éviter le doublon.",
        ],
        [
            'code' => '[vigilance_jours_suivants cache="60"]',
            'title' => 'Durée du cache',
            'desc' => "Nombre de minutes pendant lesquelles WordPress garde le JSON en mémoire avant de le redemander à GitHub. Valeur par défaut : 30. Bornes : 5 à 360. Le générateur ne publie que 4 fois par jour, inutile de descendre bas.",
        ],
        [
            'code' => '[vigilance_jours_suivants data_url="https://…"]',
            'title' => 'Source différente',
            'desc' => "Force une autre URL de JSON pour cette page uniquement, sans toucher au réglage global. Pratique pour tester une branche du dépôt avant de basculer le site.",
        ],
        [
            'code' => '[vigilance_jours_suivants title="0" cache="60"]',
            'title' => 'Attributs combinés',
            'desc' => "Les attributs se cumulent librement, séparés par une espace, dans n'importe quel ordre.",
        ],
    ];
}

function vjs_settings_page() {
    if (!current_user_can('manage_options')) return;
    $data = vjs_fetch_data(get_option('vjs_data_url', VJS_DEFAULT_DATA_URL), 5);
    $source = $data['_vjs_source'] ?? 'inconnue';
    $badges = [
        'remote' => ['#1a7f37', 'GitHub — à jour'],
        'fallback' => ['#9a6700', 'Repli embarqué'],
        'error' => ['#b42318', 'Erreur'],
    ];
    $badge = $badges[$source] ?? ['#57606a', 'Inconnue'];
    ?>
    <div class="wrap vjs-admin">
        <h1>Vigilance jours suivants</h1>
        <p class="vjs-admin-version">
            Module <strong>v<?php echo esc_html(VJS_VERSION); ?></strong> · schéma de données v3
            (départements pour J+2 et J+3, quarts de la France pour J+4 et J+5, national pour J+6 et J+7)
        </p>

        <h2 class="title">Utilisation — les shortcodes</h2>
        <p>
            Copiez l'un de ces codes et collez-le dans la page. Avec Avada, mettez-le dans un élément
            <strong>Texte</strong> ou <strong>Code</strong> de Fusion Builder — ou, si vous éditez en mode
            classique, directement dans le contenu de la page.
        </p>

        <table class="widefat striped vjs-shortcodes">
            <thead>
                <tr><th style="width:36%">Shortcode</th><th style="width:22%">Ce que ça fait</th><th>Détail</th><th style="width:90px"></th></tr>
            </thead>
            <tbody>
            <?php foreach (vjs_shortcode_reference() as $index => $entry): ?>
                <tr>
                    <td><code class="vjs-code" id="vjs-sc-<?php echo (int)$index; ?>"><?php echo esc_html($entry['code']); ?></code></td>
                    <td><strong><?php echo esc_html($entry['title']); ?></strong></td>
                    <td><?php echo esc_html($entry['desc']); ?></td>
                    <td>
                        <button type="button" class="button button-secondary vjs-copy"
                                data-target="vjs-sc-<?php echo (int)$index; ?>">Copier</button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <h3>Les attributs en un coup d'œil</h3>
        <table class="widefat striped" style="max-width:900px">
            <thead><tr><th style="width:130px">Attribut</th><th style="width:130px">Valeur par défaut</th><th>Valeurs acceptées</th></tr></thead>
            <tbody>
                <tr><td><code>title</code></td><td><code>1</code></td><td><code>1</code> affiche le bloc de titre, <code>0</code> le masque</td></tr>
                <tr><td><code>cache</code></td><td><code>30</code></td><td>nombre de minutes, ramené entre <code>5</code> et <code>360</code></td></tr>
                <tr><td><code>data_url</code></td><td>le réglage ci-dessous</td><td>URL complète d'un JSON au schéma v3</td></tr>
            </tbody>
        </table>

        <h3>Poser le module dans Avada</h3>
        <ol class="vjs-steps">
            <li>Ouvrir la page dans <strong>Fusion Builder</strong>.</li>
            <li>Ajouter un <strong>conteneur</strong> pleine largeur, puis une colonne <strong>1/1</strong> — les cartes se répartissent d'elles-mêmes en 2 puis 3 colonnes.</li>
            <li>Dans la colonne, ajouter l'élément <strong>Texte</strong> (ou <strong>Code</strong>) et y coller le shortcode.</li>
            <li>Enregistrer, puis vérifier la page côté visiteur.</li>
        </ol>
        <p class="description">
            Si le titre de la page reprend déjà « Vigilance jours suivants », préférez
            <code>[vigilance_jours_suivants title="0"]</code> pour ne pas l'afficher deux fois.
        </p>

        <hr>

        <h2 class="title">Source des données</h2>
        <form method="post" action="options.php">
            <?php settings_fields('vjs_settings'); do_settings_sections('vigilance-jours-suivants'); submit_button(); ?>
        </form>

        <h2 class="title">État actuel</h2>
        <table class="widefat striped" style="max-width:900px">
            <tbody>
            <tr>
                <td style="width:200px">Origine des données</td>
                <td>
                    <span class="vjs-badge" style="background:<?php echo esc_attr($badge[0]); ?>"><?php echo esc_html($badge[1]); ?></span>
                    <code><?php echo esc_html($source); ?></code>
                </td>
            </tr>
            <?php if (!empty($data['_vjs_remote_error'])): ?>
                <tr><td>Erreur distante</td><td><code><?php echo esc_html($data['_vjs_remote_error']); ?></code></td></tr>
            <?php endif; ?>
            <tr><td>Bulletin Météo-France</td><td><?php echo esc_html($data['bulletin']['issued_label'] ?? '—'); ?></td></tr>
            <tr><td>Données relevées le</td><td><?php echo esc_html(vjs_format_datetime($data['generated_at'] ?? '')); ?></td></tr>
            </tbody>
        </table>

        <h3>Si quelque chose cloche</h3>
        <table class="widefat striped" style="max-width:900px">
            <thead><tr><th style="width:34%">Symptôme</th><th>Cause la plus probable</th></tr></thead>
            <tbody>
                <tr>
                    <td>Le shortcode s'affiche tel quel, entre crochets</td>
                    <td>Il a été collé dans un élément qui échappe le contenu, ou l'extension est désactivée. Utiliser l'élément <strong>Texte</strong> d'Avada.</td>
                </tr>
                <tr>
                    <td>Bandeau « Données GitHub inaccessibles »</td>
                    <td>L'URL ci-dessus renvoie une erreur ou un JSON non conforme. Ouvrir l'URL dans un navigateur : elle doit afficher du JSON commençant par <code>{"schema_version": 3</code>.</td>
                </tr>
                <tr>
                    <td>Les cartes restent blanches</td>
                    <td>Le JavaScript du module n'est pas chargé — souvent un cache ou une minification agressive. Vider le cache Avada et celui du serveur.</td>
                </tr>
                <tr>
                    <td>La date du bulletin ne bouge plus</td>
                    <td>Le workflow GitHub ne tourne plus. Vérifier l'onglet <em>Actions</em> du dépôt.</td>
                </tr>
            </tbody>
        </table>

        <style>
            .vjs-admin .vjs-admin-version{color:#50575e;margin:.4em 0 1.6em}
            .vjs-admin h2.title{margin-top:2em}
            .vjs-admin .vjs-shortcodes code.vjs-code{display:inline-block;background:#f0f3f7;border:1px solid #dce3ec;border-radius:4px;padding:5px 8px;font-size:13px;white-space:nowrap}
            .vjs-admin .vjs-shortcodes td{vertical-align:middle}
            .vjs-admin .vjs-steps{max-width:900px;line-height:1.7}
            .vjs-admin .vjs-badge{display:inline-block;color:#fff;border-radius:11px;padding:2px 10px;font-size:12px;margin-right:8px}
            .vjs-admin .vjs-copy.is-done{color:#1a7f37;border-color:#1a7f37}
        </style>
        <script>
        (function(){
            function selectNode(node){
                var range = document.createRange();
                range.selectNodeContents(node);
                var selection = window.getSelection();
                selection.removeAllRanges();
                selection.addRange(range);
                return selection;
            }
            function legacyCopy(node){
                var selection = selectNode(node);
                var ok = false;
                try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
                if (ok) selection.removeAllRanges();
                return ok;
            }
            document.querySelectorAll('.vjs-copy').forEach(function(button){
                var label = button.textContent;
                button.addEventListener('click', function(){
                    var node = document.getElementById(button.dataset.target);
                    if (!node) return;
                    var flash = function(message, isError){
                        button.textContent = message;
                        button.classList.toggle('is-done', !isError);
                        setTimeout(function(){ button.textContent = label; button.classList.remove('is-done'); }, 1800);
                    };
                    var fallback = function(){
                        if (legacyCopy(node)) flash('Copié');
                        else { selectNode(node); flash('Sélectionné — Ctrl+C', true); }
                    };
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(node.textContent).then(function(){ flash('Copié'); }, fallback);
                    } else {
                        fallback();
                    }
                });
            });
        })();
        </script>
    </div>
    <?php
}

/* -------------------------------------------------------------- récupération */

add_shortcode('vigilance_jours_suivants', function ($atts = []) {
    $atts = shortcode_atts([
        'title' => '1',
        'cache' => '30',
        'data_url' => '',
    ], $atts, 'vigilance_jours_suivants');

    wp_enqueue_style('vjs-style');
    wp_enqueue_script('vjs-script');

    $data_url = esc_url_raw(trim((string)$atts['data_url']));
    if ($data_url === '') $data_url = get_option('vjs_data_url', VJS_DEFAULT_DATA_URL);

    $cache_minutes = max(5, min(360, (int)$atts['cache']));
    return vjs_render(vjs_fetch_data($data_url, $cache_minutes), $atts['title'] !== '0');
});

function vjs_fetch_data($url, $cache_minutes) {
    $cache_key = 'vjs_json_' . md5($url . '|' . VJS_VERSION);
    $cached = get_transient($cache_key);
    if (is_array($cached) && vjs_validate_data($cached)) return $cached;

    $remote_error = '';
    if ($url) {
        $response = wp_remote_get($url, [
            'timeout' => 15,
            'redirection' => 5,
            'headers' => ['Accept' => 'application/json', 'User-Agent' => 'Alertes-Meteo-VJS/' . VJS_VERSION],
        ]);
        if (is_wp_error($response)) {
            $remote_error = $response->get_error_message();
        } else {
            $code = (int)wp_remote_retrieve_response_code($response);
            if ($code >= 200 && $code < 300) {
                $decoded = json_decode(wp_remote_retrieve_body($response), true);
                if (is_array($decoded) && vjs_validate_data($decoded)) {
                    $decoded['_vjs_source'] = 'remote';
                    set_transient($cache_key, $decoded, $cache_minutes * MINUTE_IN_SECONDS);
                    return $decoded;
                }
                $remote_error = 'JSON reçu mais structure non conforme au schéma v3.';
            } else {
                $remote_error = 'HTTP ' . $code;
            }
        }
    }

    $fallback_file = VJS_PLUGIN_DIR . 'data/fallback.json';
    if (is_readable($fallback_file)) {
        $fallback = json_decode(file_get_contents($fallback_file), true);
        if (is_array($fallback) && vjs_validate_data($fallback)) {
            $fallback['_vjs_source'] = 'fallback';
            $fallback['_vjs_remote_error'] = $remote_error;
            return $fallback;
        }
    }

    return [
        'schema_version' => 3, 'status' => 'error', 'generated_at' => current_time('c'),
        'bulletin' => [], 'summaries' => [], 'cards' => [],
        '_vjs_source' => 'error', '_vjs_remote_error' => $remote_error,
    ];
}

function vjs_validate_data($data) {
    if ((int)($data['schema_version'] ?? 0) !== 3) return false;
    if (!isset($data['cards']) || !is_array($data['cards'])) return false;

    $seen = [];
    foreach ($data['cards'] as $card) {
        if (!is_array($card) || empty($card['label'])) return false;
        $granularity = $card['granularity'] ?? '';
        if ($granularity === 'department') {
            if (!isset($card['departments']) || !is_array($card['departments'])) return false;
            if (count($card['departments']) !== 96) return false;
            foreach ($card['departments'] as $info) {
                if (!is_array($info) || !in_array($info['level'] ?? '', VJS_LEVELS, true)) return false;
            }
        } elseif ($granularity === 'quadrant') {
            if (!isset($card['zones']) || !is_array($card['zones'])) return false;
            foreach (['NO', 'NE', 'SO', 'SE'] as $zone) {
                if (!in_array($card['zones'][$zone]['level'] ?? '', VJS_LEVELS, true)) return false;
            }
        } elseif ($granularity === 'national') {
            if (!in_array($card['national']['level'] ?? '', VJS_LEVELS, true)) return false;
        } else {
            return false;
        }
        $seen[$card['label']] = true;
    }
    foreach (VJS_LABELS as $label) {
        if (empty($seen[$label])) return false;
    }
    return true;
}

/* ------------------------------------------------------------------- rendu */

function vjs_get_map_svg() {
    static $svg = null;
    if ($svg !== null) return $svg;
    $file = VJS_PLUGIN_DIR . 'assets/france-departements.svg';
    $svg = is_readable($file) ? file_get_contents($file) : '';
    return $svg;
}

/** Le fond de carte n'est écrit qu'une seule fois par page ; le JS le clone. */
function vjs_map_template() {
    static $printed = false;
    if ($printed) return '';
    $printed = true;
    return '<template id="vjs-map-template">' . vjs_get_map_svg() . '</template>';
}

function vjs_find_card($cards, $label) {
    foreach ($cards as $card) {
        if (($card['label'] ?? '') === $label) return $card;
    }
    return null;
}

function vjs_render($data, $show_title) {
    $cards = is_array($data['cards'] ?? null) ? $data['cards'] : [];
    $legend = $data['legend'] ?? [];
    $issued = $data['bulletin']['issued_label'] ?? '';
    $source = $data['_vjs_source'] ?? '';

    ob_start(); ?>
    <section class="vjs-wrap" data-vjs-version="<?php echo esc_attr(VJS_VERSION); ?>"
             style="<?php echo esc_attr(vjs_palette_style($legend)); ?>">
        <?php echo vjs_map_template(); ?>

        <?php if ($show_title): ?>
            <div class="vjs-heading">
                <h2>Vigilance jours suivants</h2>
                <p>Prévision des phénomènes dangereux susceptibles d'entraîner une vigilance orange pour les prochains jours</p>
                <?php if ($issued): ?><div class="vjs-meta"><?php echo esc_html($issued); ?></div><?php endif; ?>
                <div class="vjs-version">Module v<?php echo esc_html(VJS_VERSION); ?><?php
                    if (!empty($data['generated_at'])) echo ' · Données relevées : ' . esc_html(vjs_format_datetime($data['generated_at']));
                ?></div>
            </div>
        <?php endif; ?>

        <?php if ($source === 'fallback'): ?>
            <div class="vjs-source-warning" role="status">Données GitHub inaccessibles : affichage du dernier bulletin embarqué dans le module.</div>
        <?php elseif ($source === 'error'): ?>
            <div class="vjs-source-warning vjs-source-error" role="alert">Impossible de charger le bulletin « jours suivants ».</div>
        <?php endif; ?>

        <?php if (!empty($data['summaries']['j2_j3'])): ?>
            <div class="vjs-summary"><h3>J+2 et J+3</h3><p><?php echo esc_html($data['summaries']['j2_j3']); ?></p></div>
        <?php endif; ?>

        <div class="vjs-grid vjs-grid-2">
            <?php foreach (['J+2', 'J+3'] as $label) {
                $card = vjs_find_card($cards, $label);
                if ($card) echo vjs_render_card($card);
            } ?>
        </div>

        <?php if (!empty($data['summaries']['j4_j7'])): ?>
            <div class="vjs-summary vjs-summary-second"><h3>De J+4 à J+7</h3><p><?php echo esc_html($data['summaries']['j4_j7']); ?></p></div>
        <?php endif; ?>

        <div class="vjs-grid vjs-grid-3">
            <?php foreach (['J+4', 'J+5', 'J+6 et J+7'] as $label) {
                $card = vjs_find_card($cards, $label);
                if ($card) echo vjs_render_card($card);
            } ?>
        </div>

        <?php echo vjs_render_legend($legend); ?>

        <div class="vjs-disclaimer">
            <span class="vjs-warning-icon" aria-hidden="true">▲</span>
            <p>Données issues du bulletin « Prévision des phénomènes dangereux » de
                <a href="https://vigilance.meteofrance.fr/" target="_blank" rel="noopener">Météo-France</a>
                (Licence Ouverte / Etalab 2.0). Elles indiquent une <strong>probabilité</strong> de passage en vigilance orange
                et ne se substituent pas à la carte de vigilance officielle.
                Météo-France ne publie un détail départemental que pour J+2 et J+3 ; J+4 et J+5 sont évalués par quart
                de la France, J+6 et J+7 à l'échelle de la France métropolitaine. Ce module respecte ces trois niveaux
                de précision et n'en extrapole aucun.</p>
        </div>
    </section>
    <?php
    return ob_get_clean();
}

function vjs_palette_style($legend) {
    $map = ['none' => '--vjs-none', 'low' => '--vjs-low', 'medium' => '--vjs-medium', 'high' => '--vjs-high'];
    $out = [];
    foreach (($legend['levels'] ?? []) as $entry) {
        $key = $entry['key'] ?? '';
        $colour = $entry['colour'] ?? '';
        if (isset($map[$key]) && preg_match('/^#[0-9a-fA-F]{6}$/', $colour)) {
            $out[] = $map[$key] . ':' . $colour;
        }
    }
    return implode(';', $out);
}

function vjs_render_card($card) {
    $label = $card['label'] ?? '';
    $date = $card['date_label'] ?? '';
    $granularity = $card['granularity'] ?? 'department';
    $payload = wp_json_encode($card, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

    $scope = [
        'department' => 'Détail par département',
        'quadrant' => 'Par quart de la France',
        'national' => 'France métropolitaine',
    ][$granularity] ?? '';

    ob_start(); ?>
    <article class="vjs-card">
        <div class="vjs-card-title">
            <span class="vjs-jtag"><?php echo esc_html($label); ?></span>
            <?php if ($date): ?><strong><?php echo esc_html($date); ?></strong><?php endif; ?>
        </div>
        <div class="vjs-scope"><?php echo esc_html($scope); ?></div>
        <div class="vjs-map-shell">
            <div class="vjs-map" data-granularity="<?php echo esc_attr($granularity); ?>" tabindex="0"
                 aria-label="Carte <?php echo esc_attr(trim($label . ' ' . $date)); ?> — <?php echo esc_attr($scope); ?>">
                <script type="application/json" class="vjs-card-data"><?php echo $payload; ?></script>
                <div class="vjs-tooltip" role="tooltip" aria-hidden="true"></div>
            </div>
        </div>
        <?php echo vjs_render_card_risks($card); ?>
    </article>
    <?php
    return ob_get_clean();
}

/** Résumé textuel sous la carte, construit à partir du niveau de détail réel. */
function vjs_render_card_risks($card) {
    $granularity = $card['granularity'] ?? '';
    $risks = [];

    if ($granularity === 'department') {
        foreach (($card['departments'] ?? []) as $info) {
            foreach (($info['phenomena'] ?? []) as $slug) {
                $key = $slug . '|' . $info['level'];
                $risks[$key] = ['phenomenon' => $slug, 'level' => $info['level']];
            }
        }
    } elseif ($granularity === 'quadrant') {
        foreach (($card['zones'] ?? []) as $zone) {
            foreach (($zone['phenomena'] ?? []) as $item) {
                $risks[$item['phenomenon'] . '|' . $item['level']] = $item;
            }
        }
    } elseif ($granularity === 'national') {
        foreach (($card['national']['phenomena'] ?? []) as $item) {
            $risks[$item['phenomenon'] . '|' . $item['level']] = $item;
        }
    }

    if (!$risks) {
        return '<div class="vjs-none"><span>✓</span> Aucun phénomène dangereux prévu.</div>';
    }

    usort($risks, function ($a, $b) {
        return array_search($b['level'], VJS_LEVELS, true) <=> array_search($a['level'], VJS_LEVELS, true);
    });

    ob_start(); ?>
    <div class="vjs-risks">
        <?php foreach ($risks as $risk):
            $slug = sanitize_key($risk['phenomenon']);
            $level = in_array($risk['level'], VJS_LEVELS, true) ? $risk['level'] : 'none'; ?>
            <span class="vjs-risk vjs-level-<?php echo esc_attr($level); ?>">
                <span class="vjs-risk-icon" aria-hidden="true"><?php echo esc_html(vjs_phenomenon_symbol($slug)); ?></span>
                <b><?php echo esc_html(vjs_phenomenon_name($slug)); ?></b>
                <small><?php echo esc_html(vjs_level_text($level)); ?></small>
            </span>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}

function vjs_render_legend($legend) {
    $phenomena = $legend['phenomena'] ?? array_keys(vjs_phenomenon_names());
    $levels = $legend['levels'] ?? [];
    ob_start(); ?>
    <div class="vjs-legend">
        <div class="vjs-legend-col">
            <h4>LÉGENDE DES PHÉNOMÈNES</h4>
            <div class="vjs-phenos">
                <?php foreach ($phenomena as $slug): $slug = sanitize_key($slug); ?>
                    <span class="vjs-pheno"><span class="vjs-pheno-symbol"><?php echo esc_html(vjs_phenomenon_symbol($slug)); ?></span><?php echo esc_html(vjs_phenomenon_name($slug)); ?></span>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="vjs-legend-col vjs-proba-col">
            <h4>PROBABILITÉ</h4>
            <div class="vjs-probas">
                <?php foreach (VJS_LEVELS as $key):
                    $entry = null;
                    foreach ($levels as $candidate) { if (($candidate['key'] ?? '') === $key) { $entry = $candidate; break; } }
                    $text = $entry['label'] ?? vjs_level_text($key); ?>
                    <span><i class="vjs-dot vjs-p-<?php echo esc_attr($key); ?>"></i><?php echo esc_html($text); ?></span>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/* ------------------------------------------------------------- libellés */

function vjs_phenomenon_names() {
    return [
        'vent' => 'Vent',
        'pluie_inondation' => 'Pluie-inondation',
        'orages' => 'Orages',
        'neige_verglas' => 'Neige-verglas',
        'canicule' => 'Canicule',
        'grand_froid' => 'Grand froid',
        'vagues_submersion' => 'Vagues-submersion',
    ];
}

function vjs_phenomenon_name($slug) {
    $map = vjs_phenomenon_names();
    return $map[$slug] ?? ucfirst(str_replace('_', '-', $slug));
}

function vjs_phenomenon_symbol($slug) {
    $map = [
        'vent' => '⚑', 'pluie_inondation' => '≋', 'orages' => 'ϟ', 'neige_verglas' => '✣',
        'canicule' => '☼', 'grand_froid' => '✻', 'vagues_submersion' => '≈',
    ];
    return $map[$slug] ?? '•';
}

function vjs_level_text($level) {
    $map = [
        'none' => 'Quasi nulle',
        'low' => 'Faible (≤ 30 %)',
        'medium' => 'Moyenne (> 30 ≤ 70 %)',
        'high' => 'Élevée (> 70 %)',
    ];
    return $map[$level] ?? $level;
}

function vjs_format_datetime($value) {
    if (!$value) return '';
    try {
        $dt = new DateTime($value);
        $dt->setTimezone(wp_timezone());
        return $dt->format('d/m/Y à H\hi');
    } catch (Exception $e) {
        return $value;
    }
}
